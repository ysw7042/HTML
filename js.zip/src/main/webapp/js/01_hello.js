/* JavaScript Source File */
/* => 웹문서에서 공통적으로 사용하는 기능을 제공하기 위해 선언 */
alert("JavaScript Source File에 작성된 자바스크립트 명령 실행");
